package view;


import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;

import entity.Book;
import entity.BorrowRecord;
import entity.Category;
import entity.User;
import service.BookService;
import service.BorrowRecordService;
import service.CategoryService;
import service.UserService;
import service.impl.BookServiceImpl;
import service.impl.BorrowRecordServiceImpl;
import service.impl.CategoryServiceImpl;
import service.impl.UserServiceImpl;




public class MainMenu {


    private static final Scanner sc = new Scanner(System.in);
    private static final UserService userService = new UserServiceImpl();
    private static final BookService bookService = new BookServiceImpl();
    private static final BorrowRecordService recordService = new BorrowRecordServiceImpl();
    private static final CategoryService categoryService = new CategoryServiceImpl();
    private static User loginUser;




    public static void main(String[] args) {
        login();
        while (true) {
            System.out.println("\n-------------图书管理系统--------------");
            System.out.println("当前登录：" + loginUser.getRealName());
            System.out.println("1.用户管理");
            System.out.println("2.图书管理");
            System.out.println("3.借阅图书");
            System.out.println("4.归还图书");
            System.out.println("5.查看所有借阅记录");
            System.out.println("6.按书名模糊查询");
            System.out.println("7.分类管理");
            System.out.println("8.退出系统");
            System.out.print("请选择操作序号：");


            int op = sc.nextInt();
            switch (op) {
                case 1:
                    userMenu();
                    break;
                case 2:
                    bookMenu();
                    break;
                case 3:
                    borrowBook();
                    break;
                case 4:
                    returnBook();
                    break;
                case 5:
                    showAllRecord();
                    break;
                case 6:
                    findLikeBook();
                    break;
                case 7:
                    categoryMenu();
                    break;
                case 8:
                    System.out.println("退出成功");
                    System.exit(0);
                default:
                    System.out.println("输入错误");
            }
        }
    }


    private static void login() {
        System.out.println("-------------管理员登录--------------");
        System.out.print("用户名：");
        String username = sc.next();
        System.out.print("密码：");
        String password = sc.next();


        loginUser = userService.login(username, password);
        if(loginUser == null){
            System.out.println("登录失败，账号或密码错误");
            login();
        }else {
            System.out.println("登录成功");
        }
    }


    //    用户管理
    public static void userMenu() {
        System.out.println("\n1.添加用户 2.查询所有 3.按id查询 4.返回");
        int op = sc.nextInt();
        if(op == 1){
            User u = new User();
            System.out.println("账号：");
            u.setUsername(sc.next());
            System.out.println("密码：");
            u.setPassword(sc.next());
            System.out.println("姓名：");
            u.setRealName(sc.next());
            System.out.println("电话：");
            u.setPhone(sc.next());
            System.out.println(userService.addUser(u) ? "添加成功" : "添加失败");
        } else if (op == 2) {
            userService.findAll().forEach(System.out::println);
        } else if (op == 3) {
            System.out.println("请输入用户id:");
            User u = userService.findById(sc.nextInt());
            System.out.println(u == null ? "用户不存在" : u);
        }
    }




    //    图书管理
    public static void bookMenu() {
        System.out.println("\n1.添加图书 2.查询所有 3.返回");
        int op = sc.nextInt();
        if(op == 1){
            Book b = new Book();
            System.out.println("图书名称：");
            b.setBookName(sc.next());
            System.out.println("作者：");
            b.setAuthor(sc.next());
            System.out.println("价格：");
            b.setPrice(new BigDecimal(sc.next()));
            System.out.println("库存：");
            b.setStock(sc.nextInt());
            System.out.println("分类id：");
            b.setCid(sc.nextInt());
            System.out.println(bookService.addBook(b) ? "添加成功" : "添加失败");
        } else if (op == 2) {
            bookService.findAllBooks().forEach(System.out::println);
        }
    }


    public static void borrowBook() {
        System.out.println("请输入用户id：");
        int uid = sc.nextInt();
        System.out.println("请输入图书id：");
        int bid = sc.nextInt();
        System.out.println(bookService.borrowBook(uid,bid) ? "借阅成功" : "借阅失败");
    }


    public static void returnBook() {
        System.out.print("请输入借阅记录id：");
        System.out.println(bookService.returnBook(sc.nextInt()) ? "归还成功" : "归还失败");
    }


    public static void showAllRecord() {
        List<BorrowRecord>  list = recordService.findAll();
        if(list.isEmpty()){
            System.out.println("暂无借阅记录");
        }else {
            list.forEach(System.out::println);
        }
    }


    public static void findLikeBook() {
        System.out.println("请输入书名关键词：");
        List<Book> list = bookService.findBookLikeName(sc.next());
        if(list.isEmpty()){
            System.out.println("未找到匹配图书");
        }else{
            list.forEach(System.out::println);
        }
    }


    // 分类管理
    public static void categoryMenu() {
        while (true) {
            System.out.println("\n-----分类管理-----");
            System.out.println("1.添加分类  2.查询所有  3.修改分类  4.删除分类  5.返回");
            System.out.print("请选择：");
            int op = sc.nextInt();

            if (op == 1) {
                // 添加分类
                Category c = new Category();
                System.out.print("请输入分类名称：");
                c.setName(sc.next());
                if (categoryService.addCategory(c)) {
                    System.out.println("添加成功");
                } else {
                    System.out.println("添加失败（分类名可能已存在）");
                }

            } else if (op == 2) {
                // 查询所有
                List<Category> list = categoryService.findAllCategory();
                if (list.isEmpty()) {
                    System.out.println("暂无分类");
                } else {
                    list.forEach(System.out::println);
                }

            } else if (op == 3) {
                // 修改分类
                System.out.print("请输入要修改的分类id：");
                int id = sc.nextInt();
                Category target = categoryService.findCategoryById(id);
                if (target == null) {
                    System.out.println("分类不存在");
                } else {
                    System.out.print("请输入新分类名称：");
                    target.setName(sc.next());
                    System.out.println(categoryService.updateCategory(target) ? "修改成功" : "修改失败");
                }

            } else if (op == 4) {
                // 删除分类
                System.out.print("请输入要删除的分类id：");
                int id = sc.nextInt();
                Category target = categoryService.findCategoryById(id);
                if (target == null) {
                    System.out.println("分类不存在");
                } else {
                    System.out.print("确认删除该分类？(y/n)：");
                    String confirm = sc.next();
                    if ("y".equalsIgnoreCase(confirm)) {
                        System.out.println(categoryService.deleteCategory(id) ? "删除成功" : "删除失败");
                    } else {
                        System.out.println("已取消删除");
                    }
                }

            } else if (op == 5) {
                // 返回主菜单
                break;

            } else {
                System.out.println("输入错误，请重新选择");
            }
        }
    }

}