package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.dto.UserDTO;
import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;
import com.example.demo.service.UserService;
import com.example.demo.vo.UserVO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
//用户实体类
//ServiceImpl:MP根据的IServiceImpl默认实体类
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
//    新增，修改用户
    @Override
    public boolean saveUser(UserDTO userDTO) {
//        dto转entity
        User user = new User();
        user.setId(userDTO.getId());
        user.setUsername(userDTO.getUsername());
        user.setPassword(userDTO.getPassword());
        user.setNickname(userDTO.getNickname());
        user.setPhone(userDTO.getPhone());
        user.setEmail(userDTO.getEmail());
        user.setStatus(userDTO.getStatus());
        return saveOrUpdate(user);
    }
//    查询用户列表，entity转VO返回
    @Override
    public List<UserVO> getUserList() {
        List<User> userList=list();
        List<UserVO> voList=new ArrayList<>();
        if (!CollectionUtils.isEmpty(userList))
            for (User user : userList){
                UserVO vo=new UserVO();
                vo.setId(user.getId());
                vo.setUsername(user.getUsername());
                vo.setNickname(user.getNickname());
                vo.setPhone(user.getPhone());
                vo.setEmail(user.getEmail());
                vo.setStatus(user.getStatus());
                vo.setCreateTime(user.getCreateTime());
                voList.add(vo);
            }
        return voList;
    }
}
