package com.example.demo.controller;

//用户控制器，接受前端请求，调用service,返回结果

import com.example.demo.dto.UserDTO;
import com.example.demo.service.UserService;
import com.example.demo.vo.UserVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
@Tag(name = "用户管理接口")
public class UserController {
    @Resource
    private UserService userService;

    @PatchMapping("/save")
    @Operation(summary = "新增/修改")
    public String saveUser(@Valid @RequestBody UserDTO userDTO){
        userService.saveUser(userDTO);
        return "操作成功";
    }

    @GetMapping("/list")
    @Operation(summary = "获取用户列表")
    public List<UserVO> getUserList(){
        return userService.getUserList();
    }

    @DeleteMapping("/delete/{id}")
    @Operation(summary = "删除用户")
    public String deleteUser(@PathVariable Long id){
        userService.removeById(id);
        return "删除成功";
    }

}
